/* globals describe beforeEach Controller it expect  */
describe('Question Two', () => {
  describe('adding the four CakeShops', () => {
    var theMumsPalace
    beforeEach(() => {
      theMumsPalace = Controller.setup()
    })

    it('should have added 4 CakeShop', () => {
      expect(theMumsPalace.allMyCakeShops.length).to.Be(4)
    })

    it('should have correctly set details for each CakeShop', () => {
      let aCakeShop
      aCakeShop = theMumsPalace.sortCakeShop()
      aCakeShop = theMumsPalace.allMyCakeShops[0]
      expect(aCakeShop).to.Be.Defined()
      expect(aCakeShop.id).to.Be('01')
      expect(aCakeShop.firstName).to.Be('The Bagel Shop')
      expect(aCakeShop.flavour).to.Be('Chocolate')
      expect(aCakeShop.place).to.Be('Moorhouse')

      aCakeShop = theMumsPalace.allMyCakeShops[1]
      expect(aCakeShop).to.Be.Defined()
      expect(aCakeShop.id).to.Be('02')
      expect(aCakeShop.firstName).to.Be('Hot Crossed Buns')
      expect(aCakeShop.flavour).to.Be('Vanilla')
      expect(aCakeShop.place).to.Be('Linwood')

      aCakeShop = theMumsPalace.allMyCakeShops[2]
      expect(aCakeShop).to.Be.Defined()
      expect(aCakeShop.id).to.Be('03')
      expect(aCakeShop.firstName).to.Be('Sugar Booger')
      expect(aCakeShop.flavour).to.Be('Red Velvet')
      expect(aCakeShop.place).to.Be('Shirley')

      aCakeShop = theMumsPalace.allMyCakeShops[3]
      expect(aCakeShop).to.Be.Defined()
      expect(aCakeShop.id).to.Be('04')
      expect(aCakeShop.firstName).to.Be('Patty Cakes')
      expect(aCakeShop.flavour).to.Be('Butterscotch')
      expect(aCakeShop.place).to.Be('Hornby')
    })
  })
})
