/* global describe  */
describe('Question One', () => {
  describe('Draw a class diagram', () => {})
})