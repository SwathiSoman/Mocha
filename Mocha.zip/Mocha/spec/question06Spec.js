/* globals describe beforeEach it expect CakeShop  */
describe('Question Six', () => {
  describe('CakeShop.hasTwoCakes function', () => {
    let aCakeShop, aCake
    beforeEach(() => {
      aCakeShop = new CakeShop()
      aCake = new Cake()
    })

    it('should exist', () => {
      expect(aCakeShop.hasTwoCakes).to.Be.Defined()
    })

    it('should return a boolean', () => {
      expect(typeof aCakeShop.hasTwoCakes()).to.Be('boolean')
    })

    it('should return true if the number of Cakes that CakeShop has is equal two.', () => {
      aCakeShop = new CakeShop('tao', null, null, null, null)
      aCake = aCakeShop.addCake(null, null, null, null)
      aCake = aCakeShop.addCake(null, null, null, null)
      expect(aCakeShop.hasTwoCakes()).to.Be(true)
    })

    it('should return false if the number of Cakes that CakeShop has is less than two.', () => {
      aCakeShop = new CakeShop('tao', null, null, null, null)
      aCake = aCakeShop.addCake(null, null, null, null)
      expect(aCakeShop.hasTwoCakes()).to.Be(false)
    })

    it('should return false if the number of Cakes that CakeShop owns is more than two.', () => {
      aCakeShop = new CakeShop('tao', null, null, null, null)
      aCake = aCakeShop.addCake(null, null, null, null)
      aCake = aCakeShop.addCake(null, null, null, null)
      aCake = aCakeShop.addCake(null, null, null, null)
      expect(aCakeShop.hasTwoCakes()).to.Be(false)
    })
  })
})